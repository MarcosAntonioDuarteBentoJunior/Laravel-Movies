

<?php $__env->startSection('content'); ?>
    <section id="info">
        <div class="container text-white mt-4 py-3">
            <div class="row">
                <div class="col-12 col-md-5 col-lg-4">
                    <?php if($show['poster_path']): ?>
                        <img src="<?php echo e('https://image.tmdb.org/t/p/w500/' . $show['poster_path']); ?>" class="img-fluid w-100 h-100" alt="...">
                    <?php else: ?>
                        <img src="<?php echo e(asset('public/img/no-photo.png')); ?>" class="img-fluid w-100 h-100" alt="...">
                    <?php endif; ?>                </div>
                <div class="col-12 col-md-7 col-lg-8 py-3">
                    <h2 class="mb-3 text-uppercase">
                        <?php echo e($show['name']); ?>

                    </h2>
                    <p class="mb-3">
                        <?php echo e($show['overview']); ?>

                    </p>
                    <div class="text-center d-flex justify-content-between mb-5">
                        <div>
                            <i class="fas fa-star"></i> <?php echo e($show['vote_average'] * 10 . '%'); ?>

                        </div>
                        <div>
                            <i class="fas fa-calendar-alt"></i> <?php echo e(date('d/m/Y', strtotime($show['first_air_date']))); ?>

                        </div>
                        <div>
                            <i class="fas fa-list-ul"></i>
                            <?php $__currentLoopData = $show['genres']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($genre['name']); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <h4 class="mb-3">Produção</h4>
                    <div class="mb-4">
                        <div class="d-flex">
                            <?php $__currentLoopData = $show['credits']['crew']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->index < 3): ?>
                                        <div><?php echo e($equipe['name']); ?></div>
                                        <?php
                                            $loop->index == 2 ? print('.') : print(',' . '&nbsp;')
                                        ?>
                                <?php else: ?>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php if(count($show['videos']['results']) > 0): ?>
                        <a href="https://youtube.com/watch?v=<?php echo e($show['videos']['results'][0]['key']); ?>" target="_blanck" class="btn btn-warning px-3 py-3">
                            <i class="far fa-play-circle me-2"></i> <span class="align-self-center">Ver trailer</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section id="cast">
        <div class="container mt-4">
            <h2 class="text-uppercase mb-3">Elenco Principal</h2>
            <div class="row">
                <?php $__currentLoopData = $show['credits']['cast']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elenco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index < 4): ?>
                        <div class="col-12 col-md-6 col-lg-3 mb-3 mb-lg-0">
                            <div class="card h-100 border-0 bg-dark text-white">
                                <?php if($show['poster_path']): ?>
                                    <img src="<?php echo e('https://image.tmdb.org/t/p/w500/' . $elenco['profile_path']); ?>" class="img-fluid w-100 h-100" alt="...">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('public/img/no-photo.png')); ?>" class="img-fluid w-100 h-100" alt="...">
                                <?php endif; ?>                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($elenco['name']); ?></h5>
                                    <p class="card-text"><?php echo e($elenco['character']); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="images">
        <div class="container py-4">
            <h2 class="text-uppercase mb-3">Imagens</h2>
            <div class="row">
                <?php $__currentLoopData = $show['images']['posters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-lg-4 mb-3 mb-lg-5 content">
                        <div class="card h-100 border-0">
                            <img src="<?php echo e('https://image.tmdb.org/t/p/w500/' . $image['file_path']); ?>" alt="" class="w-100">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="text-center">
                    <button id="loadMore" class="btn btn-outline-primary">Mostrar mais</button>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- JQUERY CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $(".content").slice(0, 3).show();
            if($(".content:hidden").length == 0) {
                    $("#loadMore").addClass("no-content");
                }
            $("#loadMore").on("click", function(e){
                e.preventDefault();
                $(".content:hidden").slice(0, 3).slideDown();
                if($(".content:hidden").length == 0) {
                    $("#loadMore").addClass("no-content");
                }
            });
        });
    </script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marco\Desktop\projetos php\movies\resources\views/shows/show.blade.php ENDPATH**/ ?>