<div class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3 mb-md-3">
    <div class="card h-100 bg-dark text-white">
        <img src="<?php echo e('https://image.tmdb.org/t/p/w500/' . $show['poster_path']); ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <div class="details text-center d-flex justify-content-between mb-4">
                <div>
                    <i class="fas fa-star"></i> <?php echo e($show['vote_average'] * 10 . '%'); ?>

                </div>
                <div>
                    <i class="fas fa-calendar-alt"></i> <?php echo e(date('d/m/Y', strtotime($show['first_air_date']))); ?>

                </div>
            </div>
            <h5 class="card-title"><?php echo e($show['name']); ?></h5>
            <p class="card-text">
                <?php $__currentLoopData = $show['genre_ids']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($generos->get($genre)); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <div class="text-center">
                <a href="<?php echo e(route('tv-shows.show', $show['id'])); ?>" class="btn btn-outline-primary">Ver mais</a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\marco\Desktop\projetos php\movies\resources\views/components/show-card.blade.php ENDPATH**/ ?>