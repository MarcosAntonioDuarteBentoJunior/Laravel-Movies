

<?php $__env->startSection('content'); ?>
    <section id="popular">
        <div class="container mt-4 py-3">
            <h2 class="text-uppercase mb-3">Séries Populares</h2>
            <div class="row">
                <?php $__currentLoopData = $popularShows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ShowCard::class, ['show' => $show,'generos' => $generos]); ?>
<?php $component->withName('show-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d)): ?>
<?php $component = $__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d; ?>
<?php unset($__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="top-rated">
        <div class="container py-3">
            <h2 class="text-uppercase mb-3">Séries Premiadas</h2>
            <div class="row">
                <?php $__currentLoopData = $topRatedShows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ShowCard::class, ['show' => $show,'generos' => $generos]); ?>
<?php $component->withName('show-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d)): ?>
<?php $component = $__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d; ?>
<?php unset($__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marco\Desktop\projetos php\movies\resources\views/shows/index.blade.php ENDPATH**/ ?>