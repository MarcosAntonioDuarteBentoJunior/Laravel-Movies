<nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3 border-bottom border-light">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('movies.index')); ?>"><i class="fas fa-film"></i> Laravel Movies</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('movies.index')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('movies.index')); ?>">Filmes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('shows.index')); ?>">Séries</a>
                </li>
            </ul>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-dropdown', [])->html();
} elseif ($_instance->childHasBeenRendered('L3RGsWe')) {
    $componentId = $_instance->getRenderedChildComponentId('L3RGsWe');
    $componentTag = $_instance->getRenderedChildComponentTagName('L3RGsWe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('L3RGsWe');
} else {
    $response = \Livewire\Livewire::mount('search-dropdown', []);
    $html = $response->html();
    $_instance->logRenderedChild('L3RGsWe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</nav><?php /**PATH C:\Users\marco\Desktop\projetos php\movies\resources\views/layouts/nav.blade.php ENDPATH**/ ?>