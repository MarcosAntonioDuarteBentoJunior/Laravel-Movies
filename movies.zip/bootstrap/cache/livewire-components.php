<?php return array (
  'search-dropdown' => 'App\\Http\\Livewire\\SearchDropdown',
);